import React, { Component } from "react";
import { View, Text, StyleSheet, TouchableOpacity, ImageBackground } from "react-native";
import * as Permissions from "expo-permissions";
import { BarCodeScanner } from "expo-barcode-scanner";

export default class TransactionScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      domState: "normal",
      hasCameraPermissions: null,
      scanned: false,
      scannedData: "",
      bookId: "",
      studentId: "",
    };
  }

  getCameraPermissions = async domState => {
    const { status } = await Permissions.askAsync(Permissions.CAMERA);

    this.setState({
      /*status === "granted" is true when user has granted permission
          status === "granted" is false when user has not granted the permission
        */
      hasCameraPermissions: status === "granted",
      domState: domState,
      scanned: false
    });
  };

 handleBarCodeScanned = async ({ type, data }) => {
    const { domState } = this.state;

    if (domState === "bookId") {
      this.setState({
        bookId: data,
        domState: "normal",
        scanned: true
      });
    } else if (domState === "studentId") {
      this.setState({
        studentId: data,
        domState: "normal",
        scanned: true
      });
    }
  };

  render() {
    const { studentId, bookId, domState, scanned } = this.state;
    if (domState === "scanner") {
      return (
        <BarCodeScanner
          onBarCodeScanned={scanned ? undefined : this.handleBarCodeScanned}
          style={StyleSheet.absoluteFillObject}
        />
      );
    }



    return (
      <View style={styles.container}>
      <ImageBackground source= {bgImage} style= {styles.bgImage}>
      </ImageBackground>
        <Text style={styles.text}>
          {hasCameraPermissions ? scannedData : "Request for Camera Permission"}
        </Text>
        <TouchableOpacity
          style={[styles.button, { marginTop: 25 }]}
          onPress={() => this.getCameraPermissions("scanner")}
        >
          <Text style={styles.buttonText}>Scan QR Code</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({ container: { flex: 1, backgroundColor: "#FFFFFF" },
 bgImage: { flex: 1, 
 resizeMode: "cover", 
 justifyContent: "center" }, 
 upperContainer: { flex: 0.5, 
 justifyContent: "center", 
 alignItems: "center" }, 
 appIcon: { width: 200, height: 200, 
 resizeMode: "contain", 
 marginTop: 80 }, 
 appName: { width: 80, height: 80, 
 resizeMode: "contain" }, 
 lowerContainer: { flex: 0.5, 
 alignItems: "center" }, 
 textinputContainer: { borderWidth: 2, 
 borderRadius: 10, 
 flexDirection: "row", 
 backgroundColor: "#9DFD24", 
 borderColor: "#FFFFFF" }, 
 textinput: { width: "57%", height: 50, padding: 10, 
 borderColor: "#FFFFFF", 
 borderRadius: 10, 
 borderWidth: 3, 
 fontSize: 18, 
 backgroundColor: "#5653D4", 
 fontFamily: "Rajdhani_600SemiBold", 
 color: "#FFFFFF" }, 
 scanbutton: { width: 100, height: 50, 
 backgroundColor: "#9DFD24", 
 borderBottomRightRadius: 10, 
 justifyContent: "center", 
 alignItems: "center" }, 
 scanbuttonText: { fontSize: 24, 
 color: "#0A0101", 
 fontFamily: "Rajdhani_600SemiBold" } });